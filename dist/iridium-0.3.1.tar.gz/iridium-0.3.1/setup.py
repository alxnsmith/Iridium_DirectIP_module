# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['iridium', 'iridium.examples', 'iridium.services', 'iridium.services.Messages']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'iridium',
    'version': '0.3.1',
    'description': '',
    'long_description': '',
    'author': 'alxnsmith',
    'author_email': 'alx.n.smith@ya.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
