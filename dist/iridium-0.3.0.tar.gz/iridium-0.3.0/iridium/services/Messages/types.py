BytesDict = dict[str, bytes]
